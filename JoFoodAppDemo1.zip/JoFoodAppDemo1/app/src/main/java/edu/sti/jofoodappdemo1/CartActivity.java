package edu.sti.jofoodappdemo1;

import static android.service.controls.ControlsProviderService.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.IntStream;

import edu.sti.jofoodappdemo1.Model.Cart;
import edu.sti.jofoodappdemo1.ViewHolders.CartViewHolder;

public class CartActivity extends AppCompatActivity {
    private Button nextProcessBtn;
    private TextView txtTotalAmount;

    FirebaseAuth mAuth;
    RecyclerView recyclerView;
    CartViewHolder cartAdapter;
    ArrayList<Cart> cartArrayList;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        mAuth = FirebaseAuth.getInstance();

        //Layout and recycler
        recyclerView = findViewById(R.id.cart_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = FirebaseFirestore.getInstance();
        cartArrayList = new ArrayList<Cart>();
        cartAdapter = new CartViewHolder(CartActivity.this,cartArrayList);

        recyclerView.setAdapter(cartAdapter);
        nextProcessBtn = (Button) findViewById(R.id.next_process_btn);

        nextProcessBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        txtTotalAmount = (TextView) findViewById (R.id.total_Price);

        EventChangeListener();

    }

    private void EventChangeListener() {
        String userId = mAuth.getCurrentUser().getUid();
        db.collection("USERS").document(userId)
                .collection("User Cart List")
                //connict to view holder
                 .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                            //accecpts changes nas database
                            if (error != null) {
                                Log.e("Firestore Error", error.getMessage());
                                return;
                            }
                            for (DocumentChange dc : value.getDocumentChanges())
                            {
                                if (dc.getType() == DocumentChange.Type.ADDED) {
                                    cartArrayList.add(dc.getDocument().toObject(Cart.class));
                                }
                                cartAdapter.notifyDataSetChanged();
                        }
                    }
                });
        }
    }

