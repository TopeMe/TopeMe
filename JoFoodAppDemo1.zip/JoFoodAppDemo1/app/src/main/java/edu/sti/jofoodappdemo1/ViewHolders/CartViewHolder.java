package edu.sti.jofoodappdemo1.ViewHolders;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Source;
import com.google.protobuf.StringValue;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import edu.sti.jofoodappdemo1.Adapter.Adapter;
import edu.sti.jofoodappdemo1.CartActivity;
import edu.sti.jofoodappdemo1.Model.Cart;
import edu.sti.jofoodappdemo1.Model.Pork;
import edu.sti.jofoodappdemo1.R;

public class CartViewHolder extends RecyclerView.Adapter<CartViewHolder.MyCartViewHolder>{

    Context cart_Context, context;
    ArrayList<Cart> cartArrayList;
    private int overTotalPrice = 0;
    List<String> pricesArr = new ArrayList<String>();

    int quant = 1;
    int tPrice = 0;
//    String[] pricesArr = {"idiot"};
    int priceArrCount = 0;
    public CartViewHolder(Context cart_Context, ArrayList<Cart> cartArrayList) {
        this.cart_Context = cart_Context;
        this.cartArrayList = cartArrayList;
    }

    @NonNull
    @Override
    public CartViewHolder.MyCartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(cart_Context).inflate(R.layout.cart_items_layout,parent,false);
        return new MyCartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyCartViewHolder holder, int position) {
        FirebaseAuth mAuth;
        mAuth = FirebaseAuth.getInstance();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Cart cart = cartArrayList.get(position);


        String userId = mAuth.getUid();
        String proId =  cart.getpId();

//        db.collection("USERS").document(userId)
//                .collection("User Cart List")
//                 .document(proId).get();
        //--

        db.collection("USERS").document(userId)
                .collection("User Cart List")
                .document(proId).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override

            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {

                    DocumentSnapshot document = task.getResult();
                    String tobol = (String) document.getData().get("pPrice");
                    //crash
                    int var =  (int) document.getData().get("pQuant");
                    Log.d("test", String.valueOf(var));
                    holder.cart_Pro_Quant.setText(String.valueOf(var));

                    if (document.exists()) {
                        String inputString = tobol;
                        StringBuilder sb = new StringBuilder(inputString);
                        sb.deleteCharAt(0);
                        String resultString = sb.toString();

                        pricesArr.add(resultString);
                        tPrice += Integer.valueOf(pricesArr.get(priceArrCount));
                        priceArrCount++;

                        Log.d("test", String.valueOf(tPrice));
                    }
                }
            }
        });
        //---

        String inputString = cart.getpPrice();
        StringBuilder sb = new StringBuilder(inputString);
        sb.deleteCharAt(0);
        int resultString = Integer.valueOf(sb.toString());

        //Remove peso sign


       /* int oneTypeProPrice = Integer.valueOf(resultString);
        overTotalPrice = oneTypeProPrice;
        //sa kada total price e add to an array
        int[] overall = {overTotalPrice};
        //che di amn mo add oy YAWA
        int sum = 0;
            for (int i=0; i < overall.length ; i++) {
                sum = sum + overall[i];
            }
        Log.d("olok", String.valueOf(overTotalPrice));
        Log.d("test", String.valueOf(sum));*/


        holder.cart_Pro_Name.setText(cart.getpName());
        holder.cart_Pro_Price.setText(cart.getpPrice());

        //adds
        holder.plusOne.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Cart cart = cartArrayList.get(position);
                String userId = mAuth.getUid();
                String proId =  cart.getpId();
                db.collection("USERS").document(userId)
                        .collection("User Cart List")
                            .document(proId);
                holder.cart_Pro_Quant.setText(String.valueOf(quant));
                int price = resultString * quant;

                holder.cart_Pro_Price.setText(String.valueOf("₱"+price));
                quant=quant+1;

            }
        });
        holder.removePro.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Cart cart = cartArrayList.get(position);
                String userId = mAuth.getUid();
                String proId =  cart.getpId();

                if(quant < 1)
                {
                    db.collection("USERS").document(userId)
                            .collection("User Cart List")
                            .document(proId).delete();
                    holder.cart_Pro_Quant.setText(String.valueOf(quant));

                    holder.cart_layout.setVisibility(View.GONE);
                }else{
                    quant=quant - 1;
                    holder.cart_Pro_Quant.setText(String.valueOf(quant));

                }
                int price = (resultString) * quant;
                holder.cart_Pro_Price.setText(String.valueOf("₱"+price));

            }
        });

    }

    @Override
    public int getItemCount() {
        return cartArrayList.size();
    }

    public static class MyCartViewHolder extends RecyclerView.ViewHolder{

        TextView cart_Pro_Name, cart_Pro_Price,cart_Pro_Quant;
        ConstraintLayout cart_layout;
        ImageView removePro, plusOne;

        public MyCartViewHolder(@NonNull View itemView) {
            super(itemView);
            removePro = itemView.findViewById(R.id.removePro);
            plusOne = itemView.findViewById(R.id.plusOne);
            cart_Pro_Quant = itemView.findViewById(R.id.cart_Pro_Quant);
            cart_Pro_Name = itemView.findViewById(R.id.cart_Pro_Name);
            cart_Pro_Price = itemView.findViewById(R.id.cart_Pro_Price);
            cart_layout = itemView.findViewById(R.id.productLayout);

        }
    }
}
