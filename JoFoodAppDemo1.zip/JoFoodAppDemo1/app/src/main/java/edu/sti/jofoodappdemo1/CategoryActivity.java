package edu.sti.jofoodappdemo1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;


import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import edu.sti.jofoodappdemo1.Category.PorkActivity;
import edu.sti.jofoodappdemo1.Frags.AboutFragment;

public class CategoryActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    private ImageView profile_Ic,aToC, porkBtn, seaBtn, desBtn, snackBtn, greenBtn, drinksBtn;
    private NavigationView navigationView;

    FirebaseFirestore mStore;
    //user
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        drawer = findViewById(R.id.drawer_layout);


        //OPEN THE POKING INANAG DRAWIR KADTONG MENU NAS KILID ba
        ImageView imageView = findViewById(R.id.menu_icon);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });
        //cat btns
        ImageView profile_Ic = findViewById(R.id.profile_Ic);
        ImageView profile_cart = findViewById(R.id.profile_cart);
        ImageView porkBtn = findViewById(R.id.porkImg);
        ImageView seaBtn = findViewById(R.id.seaImg);
        ImageView desBtn = findViewById(R.id.desImg);
        ImageView noodsBtn = findViewById(R.id.noodsImg);
        ImageView vegBtn = findViewById(R.id.vegImg);
        ImageView beefBtn = findViewById(R.id.beefImg);
        ImageView appeBtn = findViewById(R.id.appeImg);
        ImageView riceBtn = findViewById(R.id.riceImg);
        ImageView bfBtn = findViewById(R.id.jsImg);
        ImageView jsBtn = findViewById(R.id.jsImg);
        ImageView soupBtn = findViewById(R.id.soupImg);
        ImageView chickBtn = findViewById(R.id.chickImg);

        // pag add pag daghan onya
        profile_Ic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, ProfileActivity.class));
            }
        });

        profile_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, CartActivity.class));
            }
        });

       porkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, PorkActivity.class));
            }
        });

        seaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, SeaActivity.class));
            }
        });

        beefBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, BeefActivity.class));
            }
        });

        jsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, JsActivity.class));
            }
        });

        desBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, DesActivity.class));
            }
        });

        riceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, RiceActivity.class));
            }
        });

        noodsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, NoodsActivity.class));
            }
        });

        vegBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, VegActivity.class));
            }
        });

        appeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, AppeActivity.class));
            }
        });

        bfBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, BfActivity.class));
            }
        });

        soupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, SoupActivity.class));
            }
        });

        chickBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, ChickActivity.class));
            }
        });

        //nav
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }


    @Override
    //controls the actions inside the drawer
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        //find fragments
        AboutFragment aboutFragment = new AboutFragment();

        FragmentManager manager = getSupportFragmentManager();

        //opens fragments
        if (id == R.id.nav_msg) {
            manager.beginTransaction().replace(R.id.drawer_layout, aboutFragment, aboutFragment.getTag())
                    .commit();
            //Privacy and policy frag
            //logout
        } else if (id == R.id.nav_log){
            FirebaseAuth.getInstance().signOut();//logout
            startActivity(new Intent(getApplicationContext(),LoginActivity.class));
            finish();
            //propile
        } else if (id == R.id.nav_profile){
            startActivity(new Intent(CategoryActivity.this, ProfileActivity.class));
        }
        return true;
    }

    //when drawer is open close it with back press
    @Override
    public void onBackPressed() {
        if (this.drawer.isDrawerOpen(GravityCompat.START)) {
            this.drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


}