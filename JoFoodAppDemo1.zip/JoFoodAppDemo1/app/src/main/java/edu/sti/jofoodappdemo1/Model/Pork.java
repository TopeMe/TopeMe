package edu.sti.jofoodappdemo1.Model;

import java.util.ArrayList;

public class Pork extends ArrayList<Pork> {
    //getter setter Then constructor
    private String pName,pDetails,pImg,pId;
    private int pPrice;
    public Pork(){}
    public Pork(String pName, String pDetails, int pPrice, String pImg, String pId) {
        this.pName = pName;
        this.pDetails = pDetails;
        this.pPrice = pPrice;
        this.pImg = pImg;
        this.pId = pId;
    }

    //getter
    public String getpName() {
        return pName;
    }
    //setter
    public void setpName(String pName) {
        this.pName = pName;
    }
    //getter
    public String getpDetails() {
        return pDetails;
    }
    //setter
    public void setpDetails(String pDetails) {
        this.pDetails = pDetails;
    }
    //getter
    public int getpPrice() {
        return pPrice;
    }
    //setter
    public void setpPrice(int pPrice) {
        this.pPrice = pPrice;
    }

    public String getpImg() {
        return pImg;
    }

    public void setpImg(String pImg) {
        this.pImg = pImg;
    }

    public String getpId() {
        return pId;
    }
    public void setpId(String pId) {
        this.pId = pId;
    }

}
