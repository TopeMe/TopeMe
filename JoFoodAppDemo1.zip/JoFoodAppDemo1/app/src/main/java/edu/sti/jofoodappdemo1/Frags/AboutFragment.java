package edu.sti.jofoodappdemo1.Frags;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.navigation.NavigationView;

import edu.sti.jofoodappdemo1.R;

public class AboutFragment extends Fragment {
    //calls the this layout
    @Nullable

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      
        return inflater.inflate(R.layout.about_us_frag, container, false);

    }
}
