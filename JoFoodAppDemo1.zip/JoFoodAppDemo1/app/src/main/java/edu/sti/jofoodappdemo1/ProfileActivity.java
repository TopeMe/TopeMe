package edu.sti.jofoodappdemo1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;

import android.os.Bundle;

import android.util.Log;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class ProfileActivity extends AppCompatActivity {
    private TextView verMsg, proFName,proLName, proCon, proAdd, proEmail, resetPass;
    private Button btnLogout, resendCode;
    private String userId;
    //data retrieve
    FirebaseFirestore mStore;
    //user
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        //iaTNiztleird chu2
        mStore = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        //Profile var
        proFName = findViewById(R.id.proFName);
        proLName = findViewById(R.id.proLName);
        proEmail = findViewById(R.id.proEmail);
        proCon = findViewById(R.id.proCon);
        proAdd = findViewById(R.id.proAdd);
        //Verify msg og buttons
        resetPass = findViewById(R.id.resetPass);
        resendCode = findViewById(R.id.resendCode);
        btnLogout = findViewById(R.id.btnLogout);
        verMsg = findViewById(R.id.verMsg);

        //logout houSton We haB poRblima
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();//logout
                finish();
            }
        });


        //user
        userId = mAuth.getCurrentUser().getUid();
        //to profile thingy and gets data from the collection or doc
        DocumentReference documentReference = mStore.collection("USERS").document(userId)
                .collection("User Data").document(userId);
        //detects changes in documents
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapShot, @Nullable FirebaseFirestoreException e) {
                proFName.setText(documentSnapShot.getString("firstName"));
                proLName.setText(documentSnapShot.getString("lastName"));
                proEmail.setText(documentSnapShot.getString("email"));
                proAdd.setText(documentSnapShot.getString("contact"));
                proCon.setText(documentSnapShot.getString("address"));
            }
        });

        //email verifier
        FirebaseUser user = mAuth.getCurrentUser();
        if(!user.isEmailVerified()){
            verMsg.setVisibility(View.VISIBLE);
            resendCode.setVisibility(View.VISIBLE);
            resendCode.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    user.sendEmailVerification().addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(v.getContext(), "Verification Has been sent", Toast.LENGTH_SHORT).show();
                        }
                        //kong di mo gana
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.d("tag", "Email Not Sent " + e.getMessage());
                        }
                    });
                }
            });
        }


        //resetPass
        resetPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText resetMail = new EditText(view.getContext());
                final AlertDialog.Builder passwordResetDialog = new AlertDialog.Builder(view.getContext());
                passwordResetDialog.setTitle("Reset Password?");
                passwordResetDialog.setMessage("Enter your Email to receive reset link");
                passwordResetDialog.setView(resetMail);
                passwordResetDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //gets email and reset link
                        String email = resetMail.getText().toString();
                        mAuth.sendPasswordResetEmail(email).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(ProfileActivity.this, "Reset Link Sent", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(ProfileActivity.this, "Error! Link hasn't Sent" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
                passwordResetDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //close box
                    }
                });
                passwordResetDialog.create().show();
            }
        });
    }






    @Override
    protected void onStart(){
        super.onStart();
        //checks for current user|if not logged then go to logAct
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser==null)
        {
            startActivity(new Intent(ProfileActivity.this, LoginActivity.class));
        }
    }
}
