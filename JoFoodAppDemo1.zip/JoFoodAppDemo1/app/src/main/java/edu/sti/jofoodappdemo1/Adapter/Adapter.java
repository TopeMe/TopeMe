package edu.sti.jofoodappdemo1.Adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import edu.sti.jofoodappdemo1.CartActivity;
import edu.sti.jofoodappdemo1.Category.PorkActivity;
import edu.sti.jofoodappdemo1.Model.Cart;
import edu.sti.jofoodappdemo1.Model.Pork;
import edu.sti.jofoodappdemo1.R;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {

        //list paras mga products
    Context context;
    ArrayList<Pork> ArrayListPork;
    private int quant = 0;
    public Adapter(Context context, ArrayList<Pork> porkArrayList) {
        this.context = context;
        this.ArrayListPork = porkArrayList;
    }

    //Method 1
    @NonNull
    @Override
    public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Copies product_display na xml para e return niya/design chu2
        View view = LayoutInflater.from(context).inflate(R.layout.products_display,parent, false);

        return new MyViewHolder(view);
    }
    //method 2
    @Override
    public void onBindViewHolder(@NonNull Adapter.MyViewHolder holder, int position) {
        //Ang pork pa adto nas database
        Pork pork = ArrayListPork.get(position);
        String productID = pork.getpId();
        FirebaseAuth mAuth;
        mAuth = FirebaseAuth.getInstance();

         //Data
        holder.product_name.setText(pork.getpName());
        //loads image
        String imgUrl = pork.getpImg();
        int product_price = pork.getpPrice();

        Picasso.get().load(pork.getpImg()).fit().centerCrop().into(holder.product_image);
        //price and descripiton
        holder.product_price.setText("₱"+pork.getpPrice());
        holder.product_description.setText(pork.getpDetails());
        //passes product shet to database
        holder.product_aToC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //hashmap
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                //pass to data base
                final HashMap<String, Object> cartMap = new HashMap<>();
                //convert int
                    cartMap.put("pQuant", quant);
                    cartMap.put("pPrice", holder.product_price.getText().toString());
                    cartMap.put("pId",productID);
                    cartMap.put("pName",holder.product_name.getText().toString());
                    cartMap.put("pImg",imgUrl);
                    cartMap.put("pDetails",holder.product_description.getText().toString());
                    String proID = pork.getpId();
                //Finds collection.Passes product ID.Calls hashmap and save to firestore
                String userId = mAuth.getCurrentUser().getUid();
                db.collection("USERS").document(userId)
                        //use set for colleciton?
                        .collection("User Cart List").document(proID)
                        .set(cartMap)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(context, "Successfully Added to Cart", Toast.LENGTH_SHORT).show();
                            }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
                            }
                        });
                //set to only once
                view.setOnClickListener(null);
                holder.product_aToC.setVisibility(View.GONE);

            }
        });
    }

    //return onsay nas database
    //method 3

    @Override
    public int getItemCount() {
        return ArrayListPork.size();
    }
    //inner class
    public static class MyViewHolder extends RecyclerView.ViewHolder{
        //element or ngan sa items
        TextView product_name,product_price,product_description;
        ImageView product_image, product_aToC;
        //add pag botang ari |gets data from firebase display to recycler
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            product_aToC = itemView.findViewById(R.id.product_aToC);
            product_image = itemView.findViewById(R.id.product_image);
            product_price = itemView.findViewById(R.id.product_price);
            product_name = itemView.findViewById(R.id.product_name);
            product_description = itemView.findViewById(R.id.product_description);
        }
    }



}
