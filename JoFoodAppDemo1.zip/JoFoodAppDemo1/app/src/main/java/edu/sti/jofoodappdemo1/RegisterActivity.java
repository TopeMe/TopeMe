package edu.sti.jofoodappdemo1;

import static android.service.controls.ControlsProviderService.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

import edu.sti.jofoodappdemo1.Category.PorkActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText rEmail, rPassword, rFName, rLName, rContact, rAddress, rUName;
    private Button btnRegister;
    private TextView textLogin;
    FirebaseAuth mAuth;
    //name store and other chu2 except email and pas
    FirebaseFirestore mStore;

    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        //ayaw kalimot og instance sa firestore sunod aHAHAHhA
        mAuth = FirebaseAuth.getInstance();
        mStore = FirebaseFirestore.getInstance();
        //Variables parra sa edit text og oban chu2
        rUName = findViewById(R.id.register_uName);
        rFName = findViewById(R.id.register_fName);
        rLName = findViewById(R.id.register_LName);
        rContact = findViewById(R.id.register_ContactNo);
        rAddress = findViewById(R.id.register_Address);
        rEmail = findViewById(R.id.register_email);
        rPassword = findViewById(R.id.register_password);

        btnRegister  = findViewById(R.id.register);

        textLogin = findViewById(R.id.text_login);

        //When user is logged then go to main
        if (mAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(), CategoryActivity.class));
            finish();
        }

        //Register btn
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Register();
            }
        });
        //Login btn
        textLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });
    }

    private void Register()
    {
        //sends to firebase
        String eUname = rUName.getText().toString().trim();
        String eMail = rEmail.getText().toString().trim();
        String ePass = rPassword.getText().toString().trim();
        String eFName = rFName.getText().toString().trim();
        String eLName = rLName.getText().toString().trim();
        String eCon = rContact.getText().toString().trim();
        String eAdd = rAddress.getText().toString().trim();

        //if not then return error
        if(eUname.isEmpty())
        {
            rUName.setError("UserName can not be empty");
        }

        if(eMail.isEmpty())
        {
            rEmail.setError("Email can not be empty");
        }

        if(ePass.isEmpty())
        {
            rPassword.setError("Password can not be empty");
        }

        if(eFName.isEmpty())
        {
            rFName.setError("First Name can not be empty");
        }

        if(eLName.isEmpty())
        {
            rLName.setError("Last Name can not be empty");
        }

        if(eCon.isEmpty())
        {
            rContact.setError("Contact No. can not be empty");
        }

        if(eAdd.isEmpty())
        {
            rAddress.setError("Address can not be empty");
        }

        else
        {
            //creates email and password
            mAuth.createUserWithEmailAndPassword(eMail,ePass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    //go to Main if succ
                    if(task.isSuccessful())
                    {
                        //verify chu2
                        FirebaseUser fuser = mAuth.getCurrentUser();
                        fuser.sendEmailVerification().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                //progress bar
                                Toast.makeText(RegisterActivity.this, "Verification Has been sent", Toast.LENGTH_SHORT).show();
                            }

                            //kong di mo gana
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.d(TAG, "Email Not Sent " + e.getMessage());
                            }
                        });

                        Toast.makeText(RegisterActivity.this, "User registered successfully", Toast.LENGTH_SHORT).show();
                        //used to retrieve user id|stores profiles into users in firebase
                        userID = mAuth.getCurrentUser().getUid();

                        //Creates user data and cart list to store PEEPEE POOPOO
                        DocumentReference documentReference = mStore.collection("USERS").document(userID)
                                .collection("User Data").document(userID);
                        //hash map
                        Map<String,Object> user = new HashMap<>();
                        //gets values from edit text passes to firebase
                        user.put("userName",rUName);
                        user.put("firstName",eFName);
                        user.put("lastName",eLName);
                        user.put("email",eMail);
                        user.put("contact",eCon);
                        user.put("address",eAdd);
                        //passes to document
                        documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d(TAG, "onSuccess: user Profile is created for "+ userID);

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.d(TAG, "onFailure: " + e.toString());
                            }
                        });
                        startActivity(new Intent(RegisterActivity.this, CategoryActivity.class));
                    }
                    //Pop up Fail
                    else
                    {
                        Toast.makeText(RegisterActivity.this, "Registration Failed"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }
    }

}