package edu.sti.jofoodappdemo1.Model;

import java.util.ArrayList;

public class Cart extends ArrayList<Cart> {
    // add more paras oban categories
    private String pName,pDetails,pImg,pId,pPrice;
    //private int ;
    //cONbErT InT pRICe TO STriNG CUnT
    public Cart(){}
    public Cart(String pName, String pDetails, String pPrice, String pImg, String pId) {
        this.pName = pName;
        this.pDetails = pDetails;
        this.pPrice = pPrice;
        this.pImg = pImg;
        this.pId = pId;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public String getpDetails() {
        return pDetails;
    }

    public void setpDetails(String pDetails) {
        this.pDetails = pDetails;
    }

    public String getpPrice() {
        return pPrice;
    }

    public void setpPrice(String pPrice) {
        this.pPrice = pPrice;
    }

    public String getpImg() {
        return pImg;
    }

    public void setpImg(String pImg) {
        this.pImg = pImg;
    }

    public String getpId() {
        return pId;
    }

    public void setpId(String pId) {
        this.pId = pId;
    }
}
