package edu.sti.jofoodappdemo1.Category;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

import edu.sti.jofoodappdemo1.Adapter.Adapter;
import edu.sti.jofoodappdemo1.CartActivity;
import edu.sti.jofoodappdemo1.CategoryActivity;
import edu.sti.jofoodappdemo1.Model.Pork;
import edu.sti.jofoodappdemo1.R;



public class PorkActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Pork> porkArrayList;
    Adapter porkAdapter;
    FirebaseFirestore db;
    private String productID = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pork);
        //Display onsay nas database change na ang onsa sould sa document mao ray pakita
        //goto cart
        FloatingActionButton cart = findViewById(R.id.cart);

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PorkActivity.this, CartActivity.class));
            }
        });

        //recycler display
        recyclerView = findViewById(R.id.recycler_menu);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        productID = getIntent().getStringExtra("pId");
        //opens firestore
        db = FirebaseFirestore.getInstance();
        porkArrayList = new ArrayList<Pork>();
        porkAdapter = new Adapter(PorkActivity.this, porkArrayList);
        //adapter
        recyclerView.setAdapter(porkAdapter);

        EventChangeListener();
    }

    private void EventChangeListener() {
        //Displays the specfic data
        db.collection("Pork")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        //accecpts changes nas database
                        if (error !=    null) {
                            Log.e("Firestore Error", error.getMessage());
                            return;
                        }
                        for (DocumentChange dc : value.getDocumentChanges()) {
                            if (dc.getType() == DocumentChange.Type.ADDED) {
                                porkArrayList.add(dc.getDocument().toObject(Pork.class));
                            }
                            porkAdapter.notifyDataSetChanged();
                        }
                    }
                });
            }
        }